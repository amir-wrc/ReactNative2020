import React, { Component } from 'react';
import {
  Animated,
  StyleSheet,
  Text,
  TouchableOpacity,
} from 'react-native';


export default class Options extends Component {

  render() {
    const { value } = this.props;
    return (
      <TouchableOpacity
        activeOpacity={1}
      >
        <Animated.View
          style={styles.container}
        >
          <Text>
            {value}
          </Text>
        </Animated.View>
      </TouchableOpacity>
    );
  }

}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    borderColor: 'green',
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
    marginRight: 10,
  },
  text: {
    fontFamily: 'Avenir',
  }
});
