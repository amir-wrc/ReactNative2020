import React, {Component} from 'react';
import {View, Text, Image, Linking,ScrollView} from 'react-native';
import Card from './Card';
import Button from './Button';
import CardSection from './CardSection';
import Options from './Options';
import moment from 'moment';
export default class SecondPage extends Component {
  static navigationOptions = {
    title: 'Movie Details',
    headerStyle: {
      backgroundColor: '#232f34',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };
  // console.log("ddd",props.navigation.state.params);
  constructor(props) {
    super(props);
  }
  render() {
    const {navigate} = this.props.navigation;
    const days = [ 'Today', 'Tomorrow', moment().add(2, 'days').format('ddd, MMM D'), moment().add(3, 'days').format('ddd, MMM D'), moment().add(4, 'days').format('ddd, MMM D'), moment().add(5, 'days').format('ddd, MMM D') ];

const times = [ '9:00 AM', '11:10 AM', '12:00 PM', '1:50 PM', '4:30 PM', '6:00 PM', '7:10 PM', '9:45 PM' ];
    return (
      /**movie details page */
      <ScrollView>
      <Card>
        <CardSection>
          <View style={styles.headerContentStyle}>
            <Text style={styles.headerTextStyle}>
              {this.props.navigation.state.params.data.title}
            </Text>
            <Text>{this.props.navigation.state.params.data.year}</Text>
          </View>
        </CardSection>
        <CardSection>
          <Image
            style={styles.imageStyle}
            source={{uri: this.props.navigation.state.params.data.urlPoster}}
          />
        </CardSection>
        <CardSection>
          <Text>{this.props.navigation.state.params.data.plot}</Text>
        </CardSection>
        <CardSection>
        <Button onPress={() => Linking.openURL(this.props.navigation.state.params.data.urlIMDB)}>
          Check rating now
        </Button>
        </CardSection>
        <CardSection>
        <View>
              <Text style={styles.sectionHeader}>Day</Text>
              
              <Options
                values={days}
              />
              <Text style={styles.sectionHeader}>Movie time</Text>
              <Options
                values={times}
              />
 <CardSection>
              <Button onPress={() => navigate('Confirmation')}>Book Now</Button>
 </CardSection>
        
            </View>
        </CardSection>
       
      </Card>
      </ScrollView>
         
    );
  }
}

const styles = {
    headerStyle: {
        backgroundColor: 'red',
      },
  headerContentStyle: {
    flexDirection: 'column',
    justifyContent: 'space-around',
  },
  headerTextStyle: {
    fontSize: 18,
  },
  thumbnailStyle: {
    height: 50,
    width: 50,
  },
  thumbnailContainerStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
    marginRight: 10,
  },
  imageStyle: {
    height: 300,
    flex: 1,
    width: null,
  },
  sectionHeader: {
    color: '#AAAAAA',
  },
  buttonContainer: {
    backgroundColor: '#673AB7',
    borderRadius: 100,
    paddingVertical: 10,
    paddingHorizontal: 15,
    alignItems: 'center',
  },
  button: {
    color: '#FFFFFF',
    fontSize: 18,
    marginBottom:10
  },
};
