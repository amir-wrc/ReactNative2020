import React, {Component} from 'react';
import {View, Text, Image, Linking, ScrollView} from 'react-native';
import Card from './Card';
import Button from './Button';
import CardSection from './CardSection';
import Options from './Options';
import moment from 'moment';
import {SliderBox} from 'react-native-image-slider-box';

const days = [
  'Today',
  'Tomorrow',
  moment()
    .add(2, 'days')
    .format('ddd, MMM D'),
  moment()
    .add(3, 'days')
    .format('ddd, MMM D'),
  moment()
    .add(4, 'days')
    .format('ddd, MMM D'),
  moment()
    .add(5, 'days')
    .format('ddd, MMM D'),
];

const times = [
  '9:00 AM',
  '11:10 AM',
  '12:00 PM',
  '1:50 PM',
  '4:30 PM',
  '6:00 PM',
  '7:10 PM',
  '9:45 PM',
];
export default class SecondPage extends Component {
  static navigationOptions = {
    title: 'Movie Details',
    headerStyle: {
      backgroundColor: '#232f34',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };
  // console.log("ddd",props.navigation.state.params);
  constructor(props) {
    super(props);
  }
  state = {
    // default selected today
    chosenDay: 0,
    chosenTime: null,
  };

  onChooseDay = day => {
    this.setState({
      chosenDay: day,
    });
  };

  onChooseTime = time => {
    this.setState({
      chosenTime: time,
    });
  };

  render() {
    const {navigate} = this.props.navigation;

    return (
      /**movie details page */
      <ScrollView>
        <Card>
          <CardSection>
            <View style={styles.headerContentStyle}>
              <Text style={styles.headerTextStyle}>
                {this.props.navigation.state.params.data.Title}
              </Text>
              <Text>{this.props.navigation.state.params.data.Year}</Text>
              <Text>
                IMDB RATING-{this.props.navigation.state.params.data.imdbRating}
              </Text>
            </View>
          </CardSection>
          <CardSection>
            <SliderBox
              images={this.props.navigation.state.params.data.Images}
              style={{width: 370, height: 200}}
              dotColor="#54C7FF"
              disableOnPress
              circleLoop
              autoplay
            />
          </CardSection>
          <CardSection>
            <Text>{this.props.navigation.state.params.data.Plot}</Text>
          </CardSection>
          <CardSection>
            <Button
              onPress={() => // open Imdb site
                Linking.openURL(
                  'https://www.imdb.com/title/' +
                    this.props.navigation.state.params.data.imdbID,
                )
              }>
              Check rating now
            </Button>
          </CardSection>
          <CardSection>
            <View>
              <Text style={styles.sectionHeader}>Day</Text>

              <Options
                values={days}
                chosen={this.state.chosenDay}
                onChoose={this.onChooseDay}
              />
              <Text style={styles.sectionHeader}>Movie time</Text>
              <Options
                values={times}
                chosen={this.state.chosenTime}
                onChoose={this.onChooseTime}
              />
              <CardSection>
                <Button onPress={() => navigate('Confirmation')}>
                  Book Now
                </Button>
              </CardSection>
            </View>
          </CardSection>
        </Card>
      </ScrollView>
    );
  }
}

const styles = {
  headerContentStyle: {
    flexDirection: 'column',
    justifyContent: 'space-around',
  },
  headerTextStyle: {
    fontSize: 18,
  },
  thumbnailStyle: {
    height: 50,
    width: 50,
  },
  thumbnailContainerStyle: {
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
    marginRight: 10,
  },
  imageStyle: {
    height: 300,
    flex: 1,
    width: null,
  },
  sectionHeader: {
    color: '#AAAAAA',
  },
  buttonContainer: {
    backgroundColor: '#673AB7',
    borderRadius: 100,
    paddingVertical: 10,
    paddingHorizontal: 15,
    alignItems: 'center',
  },
  button: {
    color: '#FFFFFF',
    fontSize: 18,
    marginBottom: 10,
  },
};
