import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Image
} from 'react-native';

export default class Confirmation extends Component {
  static navigationOptions = {
    title: 'Confirmation',
    headerStyle: {
      backgroundColor: '#232f34',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <View style={styles.container}>
        <Image source={require('../assets/images/success.gif')} />
        <Text style={styles.code}>BOOKED</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  code: {
    color: 'green',
    fontSize: 36,
  },
});
