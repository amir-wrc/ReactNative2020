import React, {Component} from 'react';
import {StyleSheet, Text, TouchableOpacity, View, Image} from 'react-native';
import LottieView from 'lottie-react-native';
import {Animated, Easing} from 'react-native';

export default class Confirmation extends Component {
  static navigationOptions = {
    title: 'Confirmation',
    headerStyle: {
      backgroundColor: '#232f34',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };
  constructor(props) {
    super(props);
    this.state = {
      progress: new Animated.Value(0),
    };
  }
  componentDidMount() {
    Animated.timing(this.state.progress, {
      toValue: 1,
      duration: 1000,
      useNativeDriver: false,
      easing: Easing.linear,
    }).start();
  }
  render() {
    /**Lottievie to show gif image */
    return (
      <View style={styles.container}>
        <LottieView
          source={require('../assets/json/tick.json')}
          progress={this.state.progress}
        />
        <Text style={styles.code}>BOOKED</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  code: {
    color: '#00B304',
    fontSize: 36,
    paddingTop: 150,
  },
});
