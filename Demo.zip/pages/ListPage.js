import React, {Component} from 'react';
import { Image, TouchableOpacity} from 'react-native';
import Card from './Card';
import CardSection from './CardSection';
export default class FirstPage extends Component {
  constructor(props) {
    super(props);
  }
  /**Function to call click the movie name */
  _onPressButton = () => {
    const {navigate} = this.props.navigation;
    navigate('SecondPage', {
      data: this.props.movieData,
    });
  };
  render() {
    return (
      <TouchableOpacity
        onPress={() => {
          this._onPressButton();
        }}>
        <Card>
          <CardSection>
            <Image
              style={styles.imageStyle}
              source={{uri: this.props.movieData.Images[0]}}
            />
          </CardSection>
        </Card>
      </TouchableOpacity>
    );
  }
}

const styles = {
  imageStyle: {
    height: 300,
    flex: 1,
  },
};
