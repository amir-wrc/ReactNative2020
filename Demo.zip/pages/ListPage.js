import React, {Component} from 'react';
import { Image, TouchableOpacity} from 'react-native';
import Card from './Card';
import CardSection from './CardSection';
export default class FirstPage extends Component {
  constructor(props) {
    super(props);
  }
  _onPressButton = () => {
    const {navigate} = this.props.navigation;
    navigate('SecondPage', {
      data: this.props.movieData,
    });
  };
  render() {
    return (
      <TouchableOpacity
        onPress={() => {
          this._onPressButton();
        }}>
        <Card>
          <CardSection>
            <Image
              style={styles.imageStyle}
              source={{uri: this.props.movieData.urlPoster}}
            />
          </CardSection>
        </Card>
      </TouchableOpacity>
    );
  }
}

const styles = {
  imageStyle: {
    height: 300,
    flex: 1,
  },
};
