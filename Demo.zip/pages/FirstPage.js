import React, {Component} from 'react';
import {ScrollView} from 'react-native';
import axios from 'axios';
import ListPage from './ListPage';

export default class FirstPage extends Component {
  static navigationOptions = {
    title: 'Movies',
    headerStyle: {
      backgroundColor: '#232f34',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  state = {movies: []};

  componentDidMount() {
    //free movis api
    axios
      .get(
        'http://www.myapifilms.com/imdb/top?start=1&end=10&token=0023c194-07b2-4092-9c66-953b17ce4ca2&format=json&data=1',
      )
      .then(response => this.setState({movies: response.data.data.movies}));
  }

  renderMovies() {
    const {navigation} = this.props;
    return this.state.movies.map(movie => (
      /**Movies list */
      <ListPage key={movie.title} movieData={movie} navigation={navigation} />
    ));
  }

  render() {
    /**movie list wihin sccroll */
    return <ScrollView>{this.renderMovies()}</ScrollView>;
  }
}
