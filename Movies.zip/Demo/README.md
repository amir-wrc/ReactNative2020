Third-party component(NPM) used in Projects:

1.lottie-react-native(For lottie gif image show)

2.moment(For time or date related function)

3.react-native-image-slider-box(For image sliding)

4.react-native-splash-screen(For app splash screen configure)