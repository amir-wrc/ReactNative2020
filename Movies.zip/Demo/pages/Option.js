import React, { Component } from 'react';
import {
  Animated,
  StyleSheet,
  Text,
  TouchableOpacity,
} from 'react-native';


const colorDefault = 'rgba(255, 255, 255, 1)',
  colorSelected = 'rgba(103,58,183, 1)';

export default class Options extends Component {
  state = {
    backgroundcolor: new Animated.Value(0)
  }

  componentDidMount() {
    if (!!this.props.isChosen) {
      this.selectButton();
    }
  }

  // isChoosen prop change
  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!this.props.isChosen && !!nextProps.isChosen) {
      this.selectButton();
    } else if (!!this.props.isChosen && !nextProps.isChosen) {
      this.deselectButton();
    }
  }

  selectButton() {
    Animated.timing(this.state.backgroundcolor, {
      toValue: 100,
      duration: 200,
      useNativeDriver: false
    }).start();
  }

  deselectButton() {
    Animated.timing(this.state.backgroundcolor, {
      toValue: 0,
      duration: 200,
      useNativeDriver: false
    }).start();
  }

  render() {
    const { value, isChosen, onChoose } = this.props;
    const backgroundColorAnimation = this.state.backgroundcolor.interpolate({
      inputRange: [0, 100],
      outputRange: [colorDefault, colorSelected]
    });

    return (
      <TouchableOpacity
        activeOpacity={1}
        onPress={onChoose}>
        <Animated.View
          style={[styles.container, { backgroundColor: backgroundColorAnimation }]}>
          <Text style={{ color: isChosen ? colorDefault : colorSelected }}>
            {value}
          </Text>
        </Animated.View>
      </TouchableOpacity>
    );
  }

}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    borderColor: 'green',
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
    marginRight: 10
  },
  text: {
    fontFamily: 'Avenir',
  }
});
