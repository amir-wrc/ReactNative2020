import React, { Component } from 'react';
import { ScrollView } from 'react-native';
import ListPage from './ListPage';
import SplashScreen from 'react-native-splash-screen';
import * as response from '../assets/json/film.json';

export default class FirstPage extends Component {
  static navigationOptions = {
    title: 'Movies',
    headerStyle: {
      backgroundColor: '#232f34',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
  };

  state = { movies: [] };

  componentDidMount() {
    SplashScreen.hide();
    this.setState({ movies: response.data.movies });
  }

  renderMovies() {
    const { navigation } = this.props;
    return this.state.movies.map((movie, i) => (
      /**Movies list-- call the list page component */
      <ListPage key={i} movieData={movie} navigation={navigation} />
    ));
  }

  render() {
    /**movie list wihin sccroll */
    return <ScrollView>{this.renderMovies()}</ScrollView>;
  }
}
